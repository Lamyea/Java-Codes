/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

	public class TextPanel extends JPanel {
	  // override the paintComponent method
	  // THE MAIN DEMO OF THIS EXAMPLE:
	
	  public void paintComponent(Graphics g) {
	    super.paintComponent(g);
            setBackground(Color.white);
            g.setColor(Color.yellow);
            g.fillOval(80, 75, 128, 135);
            g.setColor(Color.black);
            g.fillOval(108,110 , 20, 25);
            g.fillOval(158, 110, 20, 25);
            g.drawArc(105, 125, 80, 60, -142, 100);
	    Font f = new Font("SansSerif", Font.BOLD, 14);
	    Font fi = new Font("SansSerif", Font.BOLD + Font.ITALIC, 14);
	    FontMetrics fm = g.getFontMetrics(f);
	    FontMetrics fim = g.getFontMetrics(fi);
	    int cx = 50; int cy = 250;
	    g.setFont(f);
	    g.drawString("Hello! My Name is  ", cx, cy);
	    cx += fm.stringWidth("Hello! My Name is ");
	    g.setFont(fi);
	    g.drawString("Lamyea!", cx, cy);
	  } //paintComponent

	  //=============================================
	  ///////////// main ////////////////////////////

	  public static void main(String[] args) {
	    JFrame f = new MyFrame("My name Frame");
	    f.show();
	  } //main
	
	} //class TextPanel

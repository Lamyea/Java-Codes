/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image;

import java.awt.Container;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

/**
 *
 * @author Nowrin
 */
class MyFrame extends JFrame {

    public MyFrame(String s) {
        //Frame parameters
        setTitle(s);
        setSize(300,300);//default size is 0,0
        setLocation(100,200);//default is 0,0()
        
        //Window Listeners
        addWindowListener(new WindowAdapter(){
                public void windowClosing(WindowEvent e){
                    System.exit(0);
                }//windowclosing
        });//addwindowListener
        
        //Add panels
        Container contentPane= getContentPane();
        contentPane.add(new TextPanel());
       
    
    }
    
}

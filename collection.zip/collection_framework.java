/**
 * 
 */
package collection;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

import javax.swing.JFileChooser;

public class collection_framework {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner filein = null;
		try {
			filein = new Scanner (new File("words.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		// Create a new Dictionary set.
		TreeSet<String> dictionary = new TreeSet<String>();
        while (filein.hasNext()) {
            String tk = filein.next();
            dictionary.add(tk);
        }
        Scanner filetest =null;
        
        File filename = getInputFileNameFromUser();
        try {
        	filetest = new Scanner (filename).useDelimiter("[^a-zA-Z]+");
        	
        } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // Now lets make a nice set from those words
        TreeSet<String> testWords = new TreeSet<String>();
        while(filetest.hasNext()){
        	testWords.add(filetest.next().toLowerCase());
        }
        //Find the words not in the dictionary
        testWords.removeAll(dictionary);
        System.out.println("Misspelled Word: Suggestions ");
        
        // Now print them out.
        
        for (String test_word :testWords) {
        	TreeSet<String> alternates = findCorrections(test_word,  dictionary);
        	if (alternates.isEmpty()){ System.out.println(test_word+": (no suggestions)");}
        	else {
        		List<String> strings = new LinkedList<String>();
        		strings.addAll(alternates);
        		System.out.println(test_word+": "+String.join(", ",strings));
        	}
        	
        }
        

	}


	
    /**
     * Lets the user select an input file using a standard file
     * selection dialog box.  If the user cancels the dialog
     * without selecting a file, the return value is null.
     */
    static File getInputFileNameFromUser() {
       JFileChooser fileDialog = new JFileChooser();
       fileDialog.setDialogTitle("Select File for Input");
       int option = fileDialog.showOpenDialog(null);
       if (option != JFileChooser.APPROVE_OPTION)
          return null;
       else
          return fileDialog.getSelectedFile();
    }
    /**This function finds all the alternatives for a given word.
    * It checks for swaped letters, substitutions and inserted spaces as well as deleted  
    */
    static TreeSet<String> findCorrections(String badWord, TreeSet<String> dictionary){
    	
    	TreeSet<String> result = new TreeSet<String>();
    	TreeSet<String> variations = new TreeSet<String>();
    	for ( int pos=0; pos < badWord.length(); pos++){
    		StringBuilder deleteLetter = new StringBuilder(badWord.toString());
    		variations.add(deleteLetter.deleteCharAt(pos).toString());
    		
    		// This section finds split words.
    		String first_word = "";
    		first_word =badWord.substring(0, pos);
    		String second_word = badWord.substring(pos);

    		if (dictionary.contains(first_word) && dictionary.contains(second_word) ){
    			result.add(first_word + " " + second_word);
    		}
    		// End of split words
    		// This finds inserted characters.
    		for (char ch='a'; ch<='z'; ch++){
    			// This replaces the later at the location
    			StringBuilder replaceLetter = new StringBuilder(badWord.toString());
    			replaceLetter.setCharAt(pos,ch);
    			variations.add(replaceLetter.toString());
    			// This adds a letter at the location
    			variations.add(badWord.substring(0,pos) + ch + badWord.substring(pos));
    		}
    	}
    	// This finds swapped characters.
    	for ( int pos=0; pos < badWord.length()-1; pos++){
    		StringBuilder tempWord = new StringBuilder(badWord.toString());
    		char char_one = tempWord.charAt(pos);
    		char char_two = tempWord.charAt(pos+1);
    		tempWord.setCharAt(pos, char_two);
    		tempWord.setCharAt(pos, char_one);
    		variations.add(tempWord.toString());
    		
    	}
    	variations.retainAll(dictionary);
    	result.addAll(variations);
    	
    	
    	return result;
    }

}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplestats;

/**
 *
 
 */
/* 
Computes and display several statistics for a set of non-zero
numbers entered by the user. (Input ends when user enters 0.)
This program uses StatCalc.java.0
*/

public class SimpleStats {

public static void main(String[] args) {

StatCalc myStatic; // Computes stats for numbers entered by user.
myStatic = new StatCalc();//creating objects for program

double item; // One number entered by the user.

TextIO.putln("Please enter your numbers one by one and then enter O to get your result.");
TextIO.putln();

do { // using loop for number input
TextIO.put("? ");
item = TextIO.getlnDouble();
if (item != 0)
myStatic.enter(item);
} while ( item != 0 );

TextIO.putln("\nStatistics about your myStatic:\n");
TextIO.putln(" Count: " + myStatic.getCount());// for numbers count
TextIO.putln(" Sum: " + myStatic.getSum());// to give sum of numbers
TextIO.putln(" Minimum: " + myStatic.getMin());// to get minimum number among numbers
TextIO.putln(" Maximum: " + myStatic.getMax());// to get maximum number among numbers
TextIO.putln(" Average: " + myStatic.getMean());// to get an average of all numbers
TextIO.putln(" Standard Deviation: " + myStatic.getStandardDeviation());// to get standard deviation

} // end main()

} // end SimpleStats class
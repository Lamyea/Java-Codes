package Unit7;

import java.util.ArrayList;
import java.util.List;

public class main {
	public static void main(String args[]){
        List<Sample> list = new ArrayList();
        Sample sample1 = new Sample(1);
        Sample sample2 = new Sample(2);
        list.add(sample1);
        Boolean contains;
        contains = list.contains(sample2);
        System.out.println("Contains: " + contains);
    }

}

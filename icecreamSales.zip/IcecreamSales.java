/**
 * This program reads from a file named "icecream.dat".  Each line of the
 * file contains the name of the ice cream's flavor and count it as sold. 
 * The program prints the total number of ice cream sold.
 * It will also print the number of cones sold with strawberry flavor and its percentage.
 */
   
public class IcecreamSales {
   
   public static void main( String[] args ) {
      
      /* Open file for reading; if it can't be opened, end the program */
      
      try {
         TextIO.readFile("icecream.dat");
      }
      catch (IllegalArgumentException e) {
         System.out.println("Can't open file \"icecream.dat\" for reading!");
         System.out.println("Please make sure the file is present before");
         System.out.println("running the program.");
	 System.exit(1);  // Terminates the program.
      }
      
      /* Read the file, keeping track of the number of ice cream sold. */
      double percentage; // straberry's percentage
      int salesTotal;  // Total number of cones sold.
      int salesSberry; // Total number of strawberry cone sold.
      String flavor; //flavor that was sold.

      salesTotal = 0;
      salesSberry=0;
      while ( ! TextIO.eof() ) {  // process one line of data.
	    salesTotal++;
            flavor = TextIO.getln(); // storing the flavor that sold.
	    if (flavor.equals("Strawberry")){
	       salesSberry++;
            }// end if
      } // end while
      percentage = (((double)salesSberry / (double)salesTotal) * 100);
      
      /* Report the results. */
      System.out.println("Total number of ice cream cones sold  " + salesTotal);
      System.out.println("Total number of Strawberry flavor ice cream cones sold  " + salesSberry);
      System.out.println((String.format("Percentage of Straberry flavor cones %.2f", percentage)+"%"));
   } // end main()
   
} // end class IcecreamSales


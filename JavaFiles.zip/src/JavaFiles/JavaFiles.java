package JavaFiles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/* public class JavaFiles {

	public static void main(String []args) {
		try {
			File myobj = new File("file.txt");
			if (myobj.createNewFile()) {
				System.out.print("File created: " + myobj.getName());
				}
			else {
				System.out.println("File already exists.");
			} 
			
		}
		catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

} */

//GetFileINfo
/* public class JavaFiles{
	public static void main(String [] args) {
		File myobj = new File("F:\\University\\apps and websites\\Java\\NOTES\\JavaFiles\\file.txt");
		if(myobj.exists()) {
			System.out.println("File name: " + myobj.getName());
			System.out.println("Absolute path: " + myobj.getAbsolutePath());
			System.out.println("Writeable: " + myobj.canWrite());
			System.out.println("Readable " + myobj.canRead());
			System.out.println("File size is bytes " + myobj.length());
		} else {
			System.out.println("file does not exist.");
		}
	}
} */

//WriteToFile
/*public class JavaFiles{
	public static void main(String []args) {
		try {
			FileWriter myWriter = new FileWriter ("file.txt");
			myWriter.write("Files in Java might be tricky, but it is fun enough! ");
			myWriter.write("I can write it by myself");
			myWriter.close();
			System.out.println("Successfully wrote to the file.");
			
		}
		catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
} */

//Read a File
public class JavaFiles{
	public static void main(String [] args) {
		try {
			File myobj = new File("file.txt");
			Scanner myReader = new Scanner(myobj);
			while(myReader.hasNextLine()) {
				String data = myReader.nextLine();
				System.out.println(data);
			}
			myReader.close();
			
		} catch(FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
			
		}
	}
}

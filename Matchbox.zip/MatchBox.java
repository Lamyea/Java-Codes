public class MatchBox extends Box {
      
       //The provided value should be density to calculate
       //weight. So, I assume that the density is given in
       //the instruction.
       double density;

       // Empty constructor
       MatchBox (){
	       ;
       }
       
       MatchBox (double w, double h, double d, double ds) {
              super (w, h, d);
	      density = ds ;
       }
       
    //Method to calculate weight
    void calculateWeight() {

	    System.out.println("Density of MatchBox is: " + density);
	    System.out.println("Weight of MatchBox is: " + width * height * depth * density);
    }
 
} 
	

public class main {

    public static void main(String[] args) {


    // Creating new object from MatchBox class 
    MatchBox calcVolume = new MatchBox(5.0, 10.0, 3.0, 0.03611);

    // Calculating volume of the box by calling getVolume method
    calcVolume.getVolume();

    // Calculating weight of the box by calling calculateWeight method
    // and the given value (0.03611) is density not weight.
    calcVolume.calculateWeight();

    }
}

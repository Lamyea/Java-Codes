/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package calcVolume;
class Box {
	 
       double width;
       double height;
       double depth;
		  
       // This is an empty constructor
       Box() {
                 ;
       }
                     
       Box (double w, double h, double d) {
              width = w;
              height = h;
              depth = d;
       }
                                   
       //Method to calculate volume
       void getVolume() {
	    System.out.println("Width of MatchBox is: " + width);
	    System.out.println("Height of MatchBox is: " + height);
	    System.out.println("Depth of MatchBox is: " + depth);
	    System.out.println("Volume is: " + width * height * depth);
       }
 }


